SELECT count(*) FROM messages;

-- Убраны запросы самому себе
DELETE FROM friend_requests
WHERE from_users_id = to_users_id;

-- Убрать медиа и сообщества у части постов
SELECT * FROM posts;

UPDATE posts
SET media_id = null
WHERE (id % 2) = 0
LIMIT 50;

UPDATE posts
SET communities_id = null
WHERE (id % 3) = 0
LIMIT 33;

-- Почистить лайки (сделать, чтобы у одного поля был не null)
-- 12 лайков - на сообщения
-- 53 лайка - на медиа
-- 33 лайка - на посты
SELECT * FROM likes;

SELECT * FROM likes
WHERE media_id IS NOT null;

UPDATE likes 
SET media_id = null, posts_id = null
LIMIT 12;

UPDATE likes
SET messages_id = null, posts_id = null
WHERE media_id IS NOT null
LIMIT 53;

UPDATE likes
SET messages_id = null, posts_id = null
WHERE media_id IS NOT null
LIMIT 53;

UPDATE likes
SET messages_id = null, media_id = null
WHERE posts_id IS NOT null
LIMIT 33;

SELECT * FROM likes
WHERE messages_id IS NOT NULL;

SELECT * FROM likes
WHERE media_id IS NOT NULL;

SELECT * FROM likes
WHERE posts_id IS NOT NULL;

-- Добавление нескольких записей в таблицу лайков
-- 1 лайк - на сообщения
-- 2 лайка - медиа
-- 4 лайка - на посты
SELECT * FROM likes;

SELECT * FROM likes
WHERE messages_id IS NOT null
ORDER BY users_id, messages_id;

INSERT INTO likes (users_id, messages_id)
VALUES (32, 5);


SELECT * FROM likes
WHERE media_id IS NOT null
ORDER BY users_id, media_id;

INSERT INTO likes (users_id, media_id)
VALUES 
	(15, 10),
    (18, 23);


SELECT * FROM likes
WHERE posts_id IS NOT null
ORDER BY users_id, posts_id;

INSERT INTO likes (users_id, posts_id)
VALUES 
	(1, 7),
    (2, 83),
    (8, 95),
    (30, 41);